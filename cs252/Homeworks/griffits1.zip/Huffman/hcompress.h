#ifndef _HCOMPRESS_H
#define _HCOMPRESS_H
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "linkedlist.c"

tnode* GenerateFreqTable(int* size){

}

tnode* CreateHuffmanTree(tnode* letters){

}

int EncodeFile(char* filename, tnode* leafNodes){

}

int DecodeFile(char* filename, tnode* treeRoot){

}


#endif
